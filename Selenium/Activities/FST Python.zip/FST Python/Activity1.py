
name= input("what is your name:")
age=int(input("what is your age:"))
year= str((2024-age)-100)
print(name +  "Is 100 years old:" + year)



